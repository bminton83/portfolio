﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CreateClassesObjs
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Course choice;

        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            Course course1 = new Course();
            Course course2 = new Course();
            Course course3 = new Course();
            Course course4 = new Course();
            Course course5 = new Course();
            Course course6 = new Course();
            Course course7 = new Course();

            course1.setName("IT 145");
            course1.setCreditHours(3);
            course2.setName("IT 200");
            course2.setCreditHours(3);
            course3.setName("IT 201");
            course3.setCreditHours(3);
            course4.setName("IT 270");
            course4.setCreditHours(3);
            course5.setName("IT 315");
            course5.setCreditHours(3);
            course6.setName("IT 328");
            course6.setCreditHours(3);
            course7.setName("IT 330");
            course7.setCreditHours(3);

            Console.WriteLine("Adding courses to comboBox");

            comboBox.Items.Add(course1);
            comboBox.Items.Add(course2);
            comboBox.Items.Add(course3);
            comboBox.Items.Add(course4);
            comboBox.Items.Add(course5);
            comboBox.Items.Add(course6);
            comboBox.Items.Add(course7);

            Console.WriteLine("Courses added to comboBox");
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            if (listBox.Items.Count >= 3)
            {
                MessageBox.Show("You have registered for the maximum number of hours.", "Limit Reached", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var selectedCourse = comboBox.SelectedItem as Course;
            if (selectedCourse == null)
            {
                MessageBox.Show("Please select a course first.", "No Selection", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            // Check for duplicates
            foreach (Course course in listBox.Items)
            {
                if (course.ToString() == selectedCourse.ToString())
                {
                    MessageBox.Show("You have already selected this course.", "Duplicate Course", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }
            }

            listBox.Items.Add(selectedCourse);
            UpdateRegisteredCoursesAndCreditHours();
        }

        private void UpdateRegisteredCoursesAndCreditHours()
        {
            registeredCoursesTextBox.Clear();
            int totalCreditHours = 0;
            foreach (Course course in listBox.Items)
            {
                registeredCoursesTextBox.AppendText(course.Name + Environment.NewLine);
                totalCreditHours += course.CreditHours;
            }
            totalCreditHoursTextBox.Text = totalCreditHours.ToString();
        }
    }

    public class Course
    {
        public string Name { get; set; }
        public int CreditHours { get; set; }

        public void setName(string name)
        {
            Name = name;
        }

        public void setCreditHours(int hours)
        {
            CreditHours = hours;
        }

        public override string ToString()
        {
            return Name;
        }
    }
}
