﻿public class Course
{
    public string Name { get; set; }
    public int CreditHours { get; set; }

    public void setName(string name)
    {
        Name = name;
    }

    public void setCreditHours(int hours)
    {
        CreditHours = hours;
    }

    public override string ToString()
    {
        return Name;
    }
}
